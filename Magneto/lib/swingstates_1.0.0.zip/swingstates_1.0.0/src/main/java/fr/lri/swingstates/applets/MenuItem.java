/*  
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Universite Paris-Sud XI, 2007. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/
package fr.lri.swingstates.applets;

import fr.lri.swingstates.canvas.CNamedTag;

public class MenuItem extends CNamedTag {
	public MenuItem(String nameItem) {
		super(nameItem);
	} 
}
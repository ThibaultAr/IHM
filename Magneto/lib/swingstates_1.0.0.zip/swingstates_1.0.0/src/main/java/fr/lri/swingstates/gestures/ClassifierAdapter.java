package fr.lri.swingstates.gestures;

import java.awt.geom.Point2D;
import java.util.Vector;

public class ClassifierAdapter implements ClassifierListener {

	public void classAdded(String className) {
		// TODO Auto-generated method stub

	}

	public void classRemoved(String className) {
		// TODO Auto-generated method stub

	}

	public void exampleAdded(String className, Gesture example) {
		// TODO Auto-generated method stub

	}

	public void exampleRemoved(String className, Gesture example) {
		// TODO Auto-generated method stub

	}

	public void templateSet(String className, Vector<Point2D> template) {
		// TODO Auto-generated method stub
		
	}

}

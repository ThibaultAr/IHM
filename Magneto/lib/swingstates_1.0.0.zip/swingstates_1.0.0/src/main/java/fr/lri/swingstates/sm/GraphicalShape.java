package fr.lri.swingstates.sm;

import java.awt.geom.Point2D;

public interface GraphicalShape {
	
	boolean isPicked(Point2D location);
	
}
